
#include "world.h"

using namespace std;

int main() {
    World w;
    w.runGame();
    return 0;
}
